<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* components/datatable.html.twig */
class __TwigTemplate_8a146045b6cd8b63c7bed651253eb17d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 32
        yield "
";
        // line 33
        $macros["alerts"] = $this->macros["alerts"] = $this->load("components/alerts_macros.html.twig", 33)->unwrap();
        // line 34
        yield "
";
        // line 35
        $context["datatable_id"] = ((array_key_exists("datatable_id", $context)) ? (Twig\Extension\CoreExtension::default(($context["datatable_id"] ?? null), ("datatable" . Twig\Extension\CoreExtension::random($this->env->getCharset())))) : (("datatable" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 36
        $context["filters"] = ((array_key_exists("filters", $context)) ? (Twig\Extension\CoreExtension::default(($context["filters"] ?? null), [])) : ([]));
        // line 37
        $context["additional_params"] = ((array_key_exists("additional_params", $context)) ? (Twig\Extension\CoreExtension::default(($context["additional_params"] ?? null), "")) : (""));
        // line 38
        $context["sort"] = ((array_key_exists("sort", $context)) ? (Twig\Extension\CoreExtension::default(($context["sort"] ?? null), null)) : (null));
        // line 39
        $context["nosort"] = ((array_key_exists("nosort", $context)) ? (Twig\Extension\CoreExtension::default(($context["nosort"] ?? null), false)) : (false));
        // line 40
        $context["order"] = ((array_key_exists("order", $context)) ? (Twig\Extension\CoreExtension::default(($context["order"] ?? null), "ASC")) : ("ASC"));
        // line 41
        $context["csv_url"] = ((array_key_exists("csv_url", $context)) ? (Twig\Extension\CoreExtension::default(($context["csv_url"] ?? null), "")) : (""));
        // line 42
        $context["footers"] = ((array_key_exists("footers", $context)) ? (Twig\Extension\CoreExtension::default(($context["footers"] ?? null), [])) : ([]));
        // line 43
        $context["showmassiveactions"] = ((array_key_exists("showmassiveactions", $context)) ? (Twig\Extension\CoreExtension::default(($context["showmassiveactions"] ?? null), false)) : (false));
        // line 44
        yield "
";
        // line 45
        if ((($tmp =  !array_key_exists("filtered_number", $context)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 46
            yield "    ";
            $context["filtered_number"] = ($context["total_number"] ?? null);
        }
        // line 48
        yield "
";
        // line 49
        $context["use_pager"] = ((array_key_exists("use_pager", $context)) ? (Twig\Extension\CoreExtension::default(($context["use_pager"] ?? null), (array_key_exists("start", $context) && array_key_exists("limit", $context)))) : ((array_key_exists("start", $context) && array_key_exists("limit", $context))));
        // line 50
        yield "
";
        // line 52
        $context["use_pager"] = ((array_key_exists("nopager", $context)) ? ( !($context["nopager"] ?? null)) : (($context["use_pager"] ?? null)));
        // line 53
        yield "
";
        // line 54
        if (((($context["total_number"] ?? null) < 1) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["filters"] ?? null)) == 0))) {
            // line 55
            yield "    <table id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["datatable_id"] ?? null), "html", null, true);
            yield "\" class=\"table\">
        <thead>
        ";
            // line 57
            if ((array_key_exists("super_header", $context) &&  !Twig\Extension\CoreExtension::testEmpty(($context["super_header"] ?? null)))) {
                // line 58
                yield "            ";
                $context["super_header_label"] = ((is_array(($context["super_header"] ?? null))) ? ((($_v0 = ($context["super_header"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["label"] ?? null) : null)) : (($context["super_header"] ?? null)));
                // line 59
                yield "            ";
                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["super_header_label"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 60
                    yield "                ";
                    $context["super_header_raw"] = ((is_array(($context["super_header"] ?? null))) ? ((((CoreExtension::getAttribute($this->env, $this->source, ($context["super_header"] ?? null), "is_raw", [], "array", true, true, false, 60) &&  !(null === (($_v1 = ($context["super_header"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["is_raw"] ?? null) : null)))) ? ((($_v2 = ($context["super_header"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["is_raw"] ?? null) : null)) : (false))) : (false));
                    // line 61
                    yield "                <tr>
                    <th colspan=\"1\">
                        ";
                    // line 63
                    yield (((($tmp = ($context["super_header_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["super_header_label"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["super_header_label"] ?? null), "html", null, true)));
                    yield "
                    </th>
                </tr>
            ";
                }
                // line 67
                yield "        ";
            }
            // line 68
            yield "        </thead>
        <tbody>
            <tr>
                <td>
                    <div class=\"alert alert-info\">
                        ";
            // line 73
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("No results found"), "html", null, true);
            yield "
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
";
        } else {
            // line 80
            yield "    ";
            $context["total_cols"] = ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["columns"] ?? null)) + (((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (1) : (0))) + (((($tmp = (((array_key_exists("nofilter", $context) &&  !(null === $context["nofilter"]))) ? ($context["nofilter"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (0) : (1)));
            // line 81
            yield "    ";
            if ((($tmp = ($context["use_pager"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 82
                yield "        ";
                yield Twig\Extension\CoreExtension::include($this->env, $context, "components/pager.html.twig", ["count" =>                 // line 83
($context["filtered_number"] ?? null), "additional_params" => ((((                // line 84
($context["additional_params"] ?? null) . "&sort=") . ($context["sort"] ?? null)) . "&order=") . ($context["order"] ?? null))]);
                // line 85
                yield "
    ";
            }
            // line 87
            yield "
    <div class=\"table-responsive ";
            // line 88
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("container_class", $context)) ? (Twig\Extension\CoreExtension::default(($context["container_class"] ?? null), "")) : ("")), "html", null, true);
            yield "\" ";
            if ((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v3 = ($context["massiveactionparams"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["container"] ?? null) : null), "html", null, true);
                yield "\" ";
            }
            yield ">
        ";
            // line 89
            if ((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 90
                yield "            <div class=\"mb-2\">
                ";
                // line 91
                $this->extensions['Glpi\Application\View\Extension\PhpExtension']->call("Html::showMassiveActions", [Twig\Extension\CoreExtension::merge(["action_button_classes" => "btn btn-sm btn-outline-secondary me-2"], ((array_key_exists("massiveactionparams", $context)) ? (Twig\Extension\CoreExtension::default(($context["massiveactionparams"] ?? null), [])) : ([])))]);
                // line 92
                yield "            </div>
        ";
            }
            // line 94
            yield "        <table id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["datatable_id"] ?? null), "html", null, true);
            yield "\" class=\"table ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("table_class_style", $context)) ? (Twig\Extension\CoreExtension::default(($context["table_class_style"] ?? null), "table-hover")) : ("table-hover")), "html", null, true);
            yield "\" aria-label=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("datatable_aria_label", $context)) ? (Twig\Extension\CoreExtension::default(($context["datatable_aria_label"] ?? null), "")) : ("")), "html", null, true);
            yield "\">
            <thead>
                ";
            // line 96
            if ((array_key_exists("super_header", $context) &&  !Twig\Extension\CoreExtension::testEmpty(($context["super_header"] ?? null)))) {
                // line 97
                yield "                    ";
                $context["super_header_label"] = ((is_array(($context["super_header"] ?? null))) ? ((($_v4 = ($context["super_header"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["label"] ?? null) : null)) : (($context["super_header"] ?? null)));
                // line 98
                yield "                    ";
                $context["super_header_raw"] = ((is_array(($context["super_header"] ?? null))) ? ((((CoreExtension::getAttribute($this->env, $this->source, ($context["super_header"] ?? null), "is_raw", [], "array", true, true, false, 98) &&  !(null === (($_v5 = ($context["super_header"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["is_raw"] ?? null) : null)))) ? ((($_v6 = ($context["super_header"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["is_raw"] ?? null) : null)) : (false))) : (false));
                // line 99
                yield "                    <tr>
                        ";
                // line 100
                if ((($tmp =  !(($context["super_header_raw"] ?? null) === "th_elements")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "<th colspan=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_cols"] ?? null), "html", null, true);
                    yield "\">";
                }
                // line 101
                yield "                            ";
                yield (((($tmp = ($context["super_header_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["super_header_label"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["super_header_label"] ?? null), "html", null, true)));
                yield "
                        ";
                // line 102
                if ((($tmp =  !(($context["super_header_raw"] ?? null) === "th_elements")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "</th>";
                }
                // line 103
                yield "                    </tr>
                ";
            }
            // line 105
            yield "                ";
            if (( !array_key_exists("no_header", $context) || (($context["no_header"] ?? null) == false))) {
                // line 106
                yield "                    <tr>
                        ";
                // line 107
                if ((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 108
                    yield "                            <th style=\"width: 30px;\">
                                <div>
                                    <input class=\"form-check-input massive_action_checkbox\" type=\"checkbox\" id=\"checkall_";
                    // line 110
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v7 = ($context["massiveactionparams"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["container"] ?? null) : null), "html", null, true);
                    yield "\"
                                        value=\"\" aria-label=\"";
                    // line 111
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Check all"), "html", null, true);
                    yield "\"
                                        onclick=\"checkAsCheckboxes(this, '";
                    // line 112
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v8 = ($context["massiveactionparams"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["container"] ?? null) : null), "js"), "html", null, true);
                    yield "', '.massive_action_checkbox');\" />
                                </div>
                            </th>
                        ";
                }
                // line 116
                yield "                        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                foreach ($context['_seq'] as $context["colkey"] => $context["column"]) {
                    // line 117
                    yield "                            ";
                    $context["column_label"] = ((is_array($context["column"])) ? ((($_v9 = $context["column"]) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["label"] ?? null) : null)) : ($context["column"]));
                    // line 118
                    yield "                            ";
                    $context["raw_header"] = ((is_array($context["column"])) ? (((CoreExtension::getAttribute($this->env, $this->source, $context["column"], "raw_header", [], "array", true, true, false, 118)) ? (Twig\Extension\CoreExtension::default((($_v10 = $context["column"]) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["raw_header"] ?? null) : null), false)) : (false))) : (false));
                    // line 119
                    yield "                            ";
                    $context["sort_icon"] = "";
                    // line 120
                    yield "                            ";
                    $context["new_order"] = "DESC";
                    // line 121
                    yield "                            ";
                    if ((($context["sort"] ?? null) == $context["colkey"])) {
                        // line 122
                        yield "                                ";
                        $context["sort_icon"] = (((($context["order"] ?? null) == "ASC")) ? ("ti ti-sort-ascending") : ((((($context["order"] ?? null) == "DESC")) ? ("ti ti-sort-descending") : (""))));
                        // line 123
                        yield "                                ";
                        $context["new_order"] = (((($context["order"] ?? null) == "ASC")) ? ("DESC") : ("ASC"));
                        // line 124
                        yield "                            ";
                    }
                    // line 125
                    yield "
                            ";
                    // line 126
                    $context["sort_href"] = (((((("javascript:reloadTab('sort=" . $context["colkey"]) . "&order=") . ($context["new_order"] ?? null)) . "&") . ($context["additional_params"] ?? null)) . "');");
                    // line 127
                    yield "
                            <th>
                                ";
                    // line 129
                    if (( !($context["nosort"] ?? null) &&  !(is_array($context["column"]) && CoreExtension::getAttribute($this->env, $this->source, $context["column"], "nosort", [], "array", true, true, false, 129)))) {
                        // line 130
                        yield "                                    <a href=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["sort_href"] ?? null), "html", null, true);
                        yield "\">
                                    <i class=\"";
                        // line 131
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["sort_icon"] ?? null), "html", null, true);
                        yield "\"></i>
                                ";
                    }
                    // line 133
                    yield "                                <span>";
                    yield (((($tmp = ($context["raw_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["column_label"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["column_label"] ?? null), "html", null, true)));
                    yield "</span>
                                ";
                    // line 134
                    if (( !($context["nosort"] ?? null) &&  !(is_array($context["column"]) && CoreExtension::getAttribute($this->env, $this->source, $context["column"], "nosort", [], "array", true, true, false, 134)))) {
                        // line 135
                        yield "                                    </a>
                                ";
                    }
                    // line 137
                    yield "                            </th>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['colkey'], $context['column'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 139
                yield "
                       ";
                // line 140
                if (( !array_key_exists("nofilter", $context) || Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["csv_url"] ?? null)))) {
                    // line 141
                    yield "                           <th>
                               <span class=\"float-end log-toolbar mb-0\">
                                   ";
                    // line 143
                    if ((($tmp =  !array_key_exists("nofilter", $context)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 144
                        yield "                                       <button class=\"btn btn-sm show_filters ";
                        yield (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["filters"] ?? null)) > 0)) ? ("btn-secondary active") : ("btn-outline-secondary"));
                        yield "\">
                                           <i class=\"ti ti-filter\"></i>
                                           <span class=\"d-none d-xl-block\">";
                        // line 146
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Filter"), "html", null, true);
                        yield "</span>
                                       </button>
                                   ";
                    }
                    // line 149
                    yield "                                   ";
                    if ((($tmp = Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["csv_url"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 150
                        yield "                                       <a href=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["csv_url"] ?? null), "html", null, true);
                        yield "\" class=\"btn btn-sm text-capitalize btn-outline-secondary\">
                                           <i class=\"ti ti-download\"></i>
                                           <span class=\"d-none d-xl-block\">";
                        // line 152
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Export"), "html", null, true);
                        yield "</span>
                                       </a>
                                   ";
                    }
                    // line 155
                    yield "                               </span>
                           </th>
                         ";
                }
                // line 158
                yield "                    </tr>
                ";
            }
            // line 160
            yield "                ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["filters"] ?? null)) > 0)) {
                // line 161
                yield "                    <tr class=\"filter_row\">
                        ";
                // line 162
                if ((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 163
                    yield "                            <td></td>
                        ";
                }
                // line 165
                yield "                        <td style=\"display: none\">
                            <input type=\"hidden\" name=\"filters[active]\" value=\"1\" />
                            <input type=\"hidden\" name=\"items_id\" value=\"";
                // line 167
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["items_id"] ?? null), "html", null, true);
                yield "\" />
                        </td>
                        ";
                // line 169
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                foreach ($context['_seq'] as $context["colkey"] => $context["colum"]) {
                    // line 170
                    yield "                            ";
                    $context["formatter"] = Twig\Extension\CoreExtension::default(((CoreExtension::getAttribute($this->env, $this->source, $context["colum"], "filter_formatter", [], "array", true, true, false, 170)) ? (Twig\Extension\CoreExtension::default((($_v11 = $context["colum"]) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["filter_formatter"] ?? null) : null), ((CoreExtension::getAttribute($this->env, $this->source, ($context["formatters"] ?? null), $context["colkey"], [], "array", true, true, false, 170)) ? (Twig\Extension\CoreExtension::default((($_v12 = ($context["formatters"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[$context["colkey"]] ?? null) : null), "")) : ("")))) : (((CoreExtension::getAttribute($this->env, $this->source, ($context["formatters"] ?? null), $context["colkey"], [], "array", true, true, false, 170)) ? (Twig\Extension\CoreExtension::default((($_v13 = ($context["formatters"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[$context["colkey"]] ?? null) : null), "")) : ("")))), "");
                    // line 171
                    yield "                            <td>
                                ";
                    // line 172
                    if (( !is_array($context["colum"]) || (((CoreExtension::getAttribute($this->env, $this->source, $context["colum"], "no_filter", [], "array", true, true, false, 172)) ? (Twig\Extension\CoreExtension::default((($_v14 = $context["colum"]) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["no_filter"] ?? null) : null), false)) : (false)) == false))) {
                        // line 173
                        yield "                                    ";
                        if (((($context["formatter"] ?? null) == "array") && CoreExtension::getAttribute($this->env, $this->source, ($context["columns_values"] ?? null), $context["colkey"], [], "array", true, true, false, 173))) {
                            // line 174
                            yield "                                           <select name=\"filters[";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["colkey"], "html", null, true);
                            yield "][]\"
                                                class=\"form-select filter-select-multiple\" multiple>
                                            ";
                            // line 176
                            $context['_parent'] = $context;
                            $context['_seq'] = CoreExtension::ensureTraversable((($_v15 = ($context["columns_values"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15[$context["colkey"]] ?? null) : null));
                            foreach ($context['_seq'] as $context["field"] => $context["value"]) {
                                // line 177
                                yield "                                                <option value=\"";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["field"], "html", null, true);
                                yield "\" ";
                                yield (((CoreExtension::getAttribute($this->env, $this->source, ($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 177) && CoreExtension::inFilter($context["field"], (($_v16 = ($context["filters"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[$context["colkey"]] ?? null) : null)))) ? ("selected") : (""));
                                yield ">
                                                    ";
                                // line 178
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                                yield "
                                                </option>
                                            ";
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['field'], $context['value'], $context['_parent']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            // line 181
                            yield "                                        </select>
                                    ";
                        } elseif ((                        // line 182
($context["formatter"] ?? null) == "datetime")) {
                            // line 183
                            yield "                                        ";
                            yield $this->extensions['Glpi\Application\View\Extension\PhpExtension']->call("Html::showDateTimeField", [(("filters[" .                             // line 184
$context["colkey"]) . "]"), ["value" => (((CoreExtension::getAttribute($this->env, $this->source,                             // line 186
($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 186) &&  !(null === (($_v17 = ($context["filters"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[$context["colkey"]] ?? null) : null)))) ? ((($_v18 = ($context["filters"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[$context["colkey"]] ?? null) : null)) : ("")), "display" => false]]);
                            // line 189
                            yield "
                                    ";
                        } elseif ((                        // line 190
($context["formatter"] ?? null) == "date")) {
                            // line 191
                            yield "                                        ";
                            yield $this->extensions['Glpi\Application\View\Extension\PhpExtension']->call("Html::showDateField", [(("filters[" .                             // line 192
$context["colkey"]) . "]"), ["value" => (((CoreExtension::getAttribute($this->env, $this->source,                             // line 194
($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 194) &&  !(null === (($_v19 = ($context["filters"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[$context["colkey"]] ?? null) : null)))) ? ((($_v20 = ($context["filters"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[$context["colkey"]] ?? null) : null)) : ("")), "display" => false]]);
                            // line 197
                            yield "
                                    ";
                        } elseif ((is_string($_v21 =                         // line 198
($context["formatter"] ?? null)) && is_string($_v22 = "progress") && str_starts_with($_v21, $_v22))) {
                            // line 199
                            yield "                                        <input type=\"range\" class=\"form-range\"
                                            name=\"filters[";
                            // line 200
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["colkey"], "html", null, true);
                            yield "]\"
                                            value=\"";
                            // line 201
                            yield (((CoreExtension::getAttribute($this->env, $this->source, ($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 201) &&  !(null === (($_v23 = ($context["filters"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23[$context["colkey"]] ?? null) : null)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v24 = ($context["filters"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24[$context["colkey"]] ?? null) : null), "html", null, true)) : (0));
                            yield "\"
                                            min=\"0\" max=\"100\" step=\"1\">
                                    ";
                        } elseif ((                        // line 203
($context["formatter"] ?? null) == "avatar")) {
                            // line 204
                            yield "                                        ";
                            // line 205
                            yield "                                    ";
                        } elseif ((($context["formatter"] ?? null) == "yesno")) {
                            // line 206
                            yield "                                        <select name=\"filters[";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["colkey"], "html", null, true);
                            yield "]\" class=\"form-select\">
                                            <option value=\"\">";
                            // line 207
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("All"), "html", null, true);
                            yield "</option>
                                            <option value=\"1\" ";
                            // line 208
                            yield ((((((CoreExtension::getAttribute($this->env, $this->source, ($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 208) &&  !(null === (($_v25 = ($context["filters"] ?? null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25[$context["colkey"]] ?? null) : null)))) ? ((($_v26 = ($context["filters"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26[$context["colkey"]] ?? null) : null)) : ("")) == "1")) ? ("selected") : (""));
                            yield ">
                                                ";
                            // line 209
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Yes"), "html", null, true);
                            yield "
                                            </option>
                                            <option value=\"0\" ";
                            // line 211
                            yield ((((((CoreExtension::getAttribute($this->env, $this->source, ($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 211) &&  !(null === (($_v27 = ($context["filters"] ?? null)) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27[$context["colkey"]] ?? null) : null)))) ? ((($_v28 = ($context["filters"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28[$context["colkey"]] ?? null) : null)) : ("")) == "0")) ? ("selected") : (""));
                            yield ">
                                                ";
                            // line 212
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("No"), "html", null, true);
                            yield "
                                            </option>
                                        </select>
                                    ";
                        } else {
                            // line 216
                            yield "                                        <input type=\"text\" class=\"form-control\"
                                            name=\"filters[";
                            // line 217
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["colkey"], "html", null, true);
                            yield "]\"
                                            value=\"";
                            // line 218
                            yield (((CoreExtension::getAttribute($this->env, $this->source, ($context["filters"] ?? null), $context["colkey"], [], "array", true, true, false, 218) &&  !(null === (($_v29 = ($context["filters"] ?? null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29[$context["colkey"]] ?? null) : null)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v30 = ($context["filters"] ?? null)) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30[$context["colkey"]] ?? null) : null), "html", null, true)) : (""));
                            yield "\">
                                    ";
                        }
                        // line 220
                        yield "                                ";
                    }
                    // line 221
                    yield "                            </td>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['colkey'], $context['colum'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 223
                yield "                    </tr>
                ";
            }
            // line 225
            yield "            </thead>
            <tbody>
                ";
            // line 227
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["entries"] ?? null)) > 0)) {
                // line 228
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 229
                    yield "                        ";
                    $context["row_massiveactions"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "showmassiveactions", [], "array", true, true, false, 229)) ? (Twig\Extension\CoreExtension::default((($_v31 = $context["entry"]) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["showmassiveactions"] ?? null) : null), ($context["showmassiveactions"] ?? null))) : (($context["showmassiveactions"] ?? null)));
                    // line 230
                    yield "                        <tr
                            class=\"";
                    // line 231
                    yield (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 231)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-transparent") : (""));
                    yield " ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("row_class", $context)) ? (Twig\Extension\CoreExtension::default(($context["row_class"] ?? null), "")) : ("")), "html", null, true);
                    yield " ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "row_class", [], "array", true, true, false, 231)) ? (Twig\Extension\CoreExtension::default((($_v32 = $context["entry"]) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["row_class"] ?? null) : null), "")) : ("")), "html", null, true);
                    yield "\"
                            ";
                    // line 232
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "itemtype", [], "array", true, true, false, 232)) {
                        // line 233
                        yield "                                data-itemtype=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v33 = $context["entry"]) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["itemtype"] ?? null) : null), "html", null, true);
                        yield "\"
                            ";
                    }
                    // line 235
                    yield "                            ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "id", [], "array", true, true, false, 235)) {
                        // line 236
                        yield "                                data-id=\"";
                        yield (((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "id", [], "array", true, true, false, 236) &&  !(null === (($_v34 = $context["entry"]) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["id"] ?? null) : null)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v35 = $context["entry"]) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["id"] ?? null) : null), "html", null, true)) : (""));
                        yield "\"
                            ";
                    }
                    // line 238
                    yield "                            ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "row_aria_label", [], "array", true, true, false, 238)) {
                        // line 239
                        yield "                                aria-label=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v36 = $context["entry"]) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["row_aria_label"] ?? null) : null), "html", null, true);
                        yield "\"
                            ";
                    }
                    // line 241
                    yield "                        >
                            ";
                    // line 242
                    if ((($tmp = ($context["row_massiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 243
                        yield "                                <td style=\"width: 10px\">
                                    ";
                        // line 244
                        if (( !CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "skip_ma", [], "array", true, true, false, 244) || ((($_v37 = $context["entry"]) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["skip_ma"] ?? null) : null) == false))) {
                            // line 245
                            yield "                                        <input class=\"form-check-input massive_action_checkbox\" type=\"checkbox\" data-glpicore-ma-tags=\"common\"
                                               value=\"1\" aria-label=\"";
                            // line 246
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Select item"), "html", null, true);
                            yield "\"
                                               name=\"item[";
                            // line 247
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v38 = $context["entry"]) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["itemtype"] ?? null) : null), "html", null, true);
                            yield "][";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v39 = $context["entry"]) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39["id"] ?? null) : null), "html", null, true);
                            yield "]\" />
                                    ";
                        }
                        // line 249
                        yield "                                </td>
                            ";
                    }
                    // line 251
                    yield "                            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                    foreach ($context['_seq'] as $context["colkey"] => $context["colum"]) {
                        // line 252
                        yield "                                ";
                        if (CoreExtension::inFilter($context["colkey"], Twig\Extension\CoreExtension::keys($context["entry"]))) {
                            // line 253
                            yield "                                    ";
                            $context["colspan"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], ($context["colkey"] . "_colspan"), [], "array", true, true, false, 253)) ? (Twig\Extension\CoreExtension::default((($_v40 = $context["entry"]) && is_array($_v40) || $_v40 instanceof ArrayAccess ? ($_v40[($context["colkey"] . "_colspan")] ?? null) : null), 1)) : (1));
                            // line 254
                            yield "                                    ";
                            $context["aria_label"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], ($context["colkey"] . "_aria_label"), [], "array", true, true, false, 254)) ? (Twig\Extension\CoreExtension::default((($_v41 = $context["entry"]) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41[($context["colkey"] . "_aria_label")] ?? null) : null), "")) : (""));
                            // line 255
                            yield "                                    <td colspan=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["colspan"] ?? null), "html", null, true);
                            yield "\" aria-label=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["aria_label"] ?? null), "html", null, true);
                            yield "\">

                                        ";
                            // line 257
                            $context["formatter"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["formatters"] ?? null), $context["colkey"], [], "array", true, true, false, 257) &&  !(null === (($_v42 = ($context["formatters"] ?? null)) && is_array($_v42) || $_v42 instanceof ArrayAccess ? ($_v42[$context["colkey"]] ?? null) : null)))) ? ((($_v43 = ($context["formatters"] ?? null)) && is_array($_v43) || $_v43 instanceof ArrayAccess ? ($_v43[$context["colkey"]] ?? null) : null)) : (""));
                            // line 258
                            yield "
                                        ";
                            // line 259
                            if ((($context["formatter"] ?? null) == "maintext")) {
                                // line 260
                                yield "                                            <span class=\"d-inline-block bg-blue-lt p-1 text-truncate\"
                                                title=\"";
                                // line 261
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v44 = $context["entry"]) && is_array($_v44) || $_v44 instanceof ArrayAccess ? ($_v44[$context["colkey"]] ?? null) : null), "html", null, true);
                                yield "\"
                                                data-bs-toggle=\"tooltip\"
                                                style=\"max-width: 250px;\">
                                                ";
                                // line 264
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v45 = $context["entry"]) && is_array($_v45) || $_v45 instanceof ArrayAccess ? ($_v45[$context["colkey"]] ?? null) : null), "html", null, true);
                                yield "
                                            </span>
                                        ";
                            } elseif ((                            // line 266
($context["formatter"] ?? null) == "longtext")) {
                                // line 267
                                yield "                                            <span class=\"d-inline-block text-truncate\"
                                                title=\"";
                                // line 268
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v46 = $context["entry"]) && is_array($_v46) || $_v46 instanceof ArrayAccess ? ($_v46[$context["colkey"]] ?? null) : null), "html", null, true);
                                yield "\"
                                                data-bs-toggle=\"tooltip\"
                                                style=\"max-width: 250px;\">
                                                ";
                                // line 271
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v47 = $context["entry"]) && is_array($_v47) || $_v47 instanceof ArrayAccess ? ($_v47[$context["colkey"]] ?? null) : null), "html", null, true);
                                yield "
                                            </span>
                                        ";
                            } elseif ((is_string($_v48 =                             // line 273
($context["formatter"] ?? null)) && is_string($_v49 = "progress") && str_starts_with($_v48, $_v49))) {
                                // line 274
                                yield "                                            ";
                                yield $this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getProgressBar((($_v50 = $context["entry"]) && is_array($_v50) || $_v50 instanceof ArrayAccess ? ($_v50[$context["colkey"]] ?? null) : null));
                                yield "
                                        ";
                            } elseif ((                            // line 275
($context["formatter"] ?? null) == "date")) {
                                // line 276
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getFormattedDate((($_v51 = $context["entry"]) && is_array($_v51) || $_v51 instanceof ArrayAccess ? ($_v51[$context["colkey"]] ?? null) : null)), "html", null, true);
                                yield "
                                        ";
                            } elseif ((                            // line 277
($context["formatter"] ?? null) == "datetime")) {
                                // line 278
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getFormattedDatetime((($_v52 = $context["entry"]) && is_array($_v52) || $_v52 instanceof ArrayAccess ? ($_v52[$context["colkey"]] ?? null) : null)), "html", null, true);
                                yield "
                                        ";
                            } elseif ((                            // line 279
($context["formatter"] ?? null) == "duration")) {
                                // line 280
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getFormattedDuration((($_v53 = $context["entry"]) && is_array($_v53) || $_v53 instanceof ArrayAccess ? ($_v53[$context["colkey"]] ?? null) : null)), "html", null, true);
                                yield "
                                        ";
                            } elseif ((                            // line 281
($context["formatter"] ?? null) == "bytesize")) {
                                // line 282
                                yield "                                            ";
                                yield $this->extensions['Glpi\Application\View\Extension\PhpExtension']->call("Toolbox::getSize", [(($_v54 = $context["entry"]) && is_array($_v54) || $_v54 instanceof ArrayAccess ? ($_v54[$context["colkey"]] ?? null) : null)]);
                                yield "
                                        ";
                            } elseif ((                            // line 283
($context["formatter"] ?? null) == "number")) {
                                // line 284
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getFormattedNumber((($_v55 = $context["entry"]) && is_array($_v55) || $_v55 instanceof ArrayAccess ? ($_v55[$context["colkey"]] ?? null) : null)), "html", null, true);
                                yield "
                                        ";
                            } elseif ((                            // line 285
($context["formatter"] ?? null) == "integer")) {
                                // line 286
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Glpi\Application\View\Extension\DataHelpersExtension']->getFormattedInteger((($_v56 = $context["entry"]) && is_array($_v56) || $_v56 instanceof ArrayAccess ? ($_v56[$context["colkey"]] ?? null) : null)), "html", null, true);
                                yield "
                                        ";
                            } elseif ((                            // line 287
($context["formatter"] ?? null) == "raw_html")) {
                                // line 288
                                yield "                                            ";
                                yield (($_v57 = $context["entry"]) && is_array($_v57) || $_v57 instanceof ArrayAccess ? ($_v57[$context["colkey"]] ?? null) : null);
                                yield "
                                        ";
                            } elseif ((                            // line 289
($context["formatter"] ?? null) == "avatar")) {
                                // line 290
                                yield "                                            ";
                                // line 291
                                yield "                                            ";
                                $context["entry_data"] = (($_v58 = $context["entry"]) && is_array($_v58) || $_v58 instanceof ArrayAccess ? ($_v58[$context["colkey"]] ?? null) : null);
                                // line 292
                                yield "                                            ";
                                $context["avatar_size"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["entry_data"] ?? null), "avatar_size", [], "array", true, true, false, 292) &&  !(null === (($_v59 = ($context["entry_data"] ?? null)) && is_array($_v59) || $_v59 instanceof ArrayAccess ? ($_v59["avatar_size"] ?? null) : null)))) ? ((($_v60 = ($context["entry_data"] ?? null)) && is_array($_v60) || $_v60 instanceof ArrayAccess ? ($_v60["avatar_size"] ?? null) : null)) : ("avatar-md"));
                                // line 293
                                yield "                                            ";
                                $context["img"] = (($_v61 = ($context["entry_data"] ?? null)) && is_array($_v61) || $_v61 instanceof ArrayAccess ? ($_v61["picture"] ?? null) : null);
                                // line 294
                                yield "                                            ";
                                $context["initials"] = (($_v62 = ($context["entry_data"] ?? null)) && is_array($_v62) || $_v62 instanceof ArrayAccess ? ($_v62["initials"] ?? null) : null);
                                // line 295
                                yield "                                            ";
                                $context["bg_color"] = (((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["img"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("inherit") : ((($_v63 = ($context["entry_data"] ?? null)) && is_array($_v63) || $_v63 instanceof ArrayAccess ? ($_v63["initials_bg"] ?? null) : null)));
                                // line 296
                                yield "                                            <span class=\"avatar ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar_size"] ?? null), "html", null, true);
                                yield " rounded\"
                                                style=\"";
                                // line 297
                                if ((($tmp =  !(null === ($context["img"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    yield " background-image: url(";
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["img"] ?? null), "html", null, true);
                                    yield "); ";
                                }
                                yield " background-color: ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["bg_color"] ?? null), "html", null, true);
                                yield "\">
                                                ";
                                // line 298
                                if (Twig\Extension\CoreExtension::testEmpty(($context["img"] ?? null))) {
                                    // line 299
                                    yield "                                                    ";
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["initials"] ?? null), "html", null, true);
                                    yield "
                                                ";
                                }
                                // line 301
                                yield "                                            </span>
                                        ";
                            } elseif (((                            // line 302
($context["formatter"] ?? null) == "badge") &&  !Twig\Extension\CoreExtension::testEmpty((($_v64 = $context["entry"]) && is_array($_v64) || $_v64 instanceof ArrayAccess ? ($_v64[$context["colkey"]] ?? null) : null)))) {
                                // line 303
                                yield "                                            ";
                                $context["entry_data"] = (($_v65 = $context["entry"]) && is_array($_v65) || $_v65 instanceof ArrayAccess ? ($_v65[$context["colkey"]] ?? null) : null);
                                // line 304
                                yield "                                            ";
                                $context["content"] = (($_v66 = ($context["entry_data"] ?? null)) && is_array($_v66) || $_v66 instanceof ArrayAccess ? ($_v66["content"] ?? null) : null);
                                // line 305
                                yield "                                            ";
                                $context["color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["entry_data"] ?? null), "color", [], "array", true, true, false, 305) &&  !(null === (($_v67 = ($context["entry_data"] ?? null)) && is_array($_v67) || $_v67 instanceof ArrayAccess ? ($_v67["color"] ?? null) : null)))) ? ((($_v68 = ($context["entry_data"] ?? null)) && is_array($_v68) || $_v68 instanceof ArrayAccess ? ($_v68["color"] ?? null) : null)) : ("#BBBBBB"));
                                // line 306
                                yield "                                            ";
                                if ((($tmp =  !CoreExtension::matches("/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})\$/", ($context["color"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 307
                                    yield "                                                ";
                                    $context["color"] = "#BBBBBB";
                                    // line 308
                                    yield "                                            ";
                                }
                                // line 309
                                yield "                                            ";
                                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["content"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 310
                                    yield "                                                <div class=\"badge_block\" style=\"border-color: ";
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                                    yield "\">
                                                    <span class=\"me-1\" style=\"background: ";
                                    // line 311
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                                    yield "\"></span>
                                                    ";
                                    // line 312
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["content"] ?? null), "html", null, true);
                                    yield "
                                                </div>
                                            ";
                                }
                                // line 315
                                yield "                                        ";
                            } elseif ((($context["formatter"] ?? null) == "yesno")) {
                                // line 316
                                yield "                                            ";
                                if (((($_v69 = $context["entry"]) && is_array($_v69) || $_v69 instanceof ArrayAccess ? ($_v69[$context["colkey"]] ?? null) : null) == 1)) {
                                    // line 317
                                    yield "                                                <div aria-label=\"";
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Yes"), "html", null, true);
                                    yield "\"><i class=\"ti ti-circle-check\"></i></div>
                                            ";
                                } else {
                                    // line 319
                                    yield "                                                <div aria-label=\"";
                                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("No"), "html", null, true);
                                    yield "\"></div>
                                            ";
                                }
                                // line 321
                                yield "                                        ";
                            } else {
                                // line 322
                                yield "                                            ";
                                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v70 = $context["entry"]) && is_array($_v70) || $_v70 instanceof ArrayAccess ? ($_v70[$context["colkey"]] ?? null) : null), "html", null, true);
                                yield "
                                        ";
                            }
                            // line 324
                            yield "                                    </td>
                                ";
                        }
                        // line 326
                        yield "                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['colkey'], $context['colum'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 327
                    yield "                            ";
                    if ((($tmp =  !(((array_key_exists("nofilter", $context) &&  !(null === $context["nofilter"]))) ? ($context["nofilter"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 328
                        yield "                                <td></td>
                            ";
                    }
                    // line 330
                    yield "                        </tr>
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 332
                yield "                ";
            } else {
                // line 333
                yield "                    <tr>
                        <td colspan=\"";
                // line 334
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_cols"] ?? null), "html", null, true);
                yield "\">
                            ";
                // line 335
                yield $macros["alerts"]->getTemplateForMacro("macro_alert_info", $context, 335, $this->getSourceContext())->macro_alert_info(...[__("No results found")]);
                yield "
                        </td>
                    </tr>
                ";
            }
            // line 339
            yield "            </tbody>
            ";
            // line 340
            if ((($tmp = ($context["footers"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 341
                yield "                <tfoot class=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("footer_class", $context)) ? (Twig\Extension\CoreExtension::default(($context["footer_class"] ?? null), "")) : ("")), "html", null, true);
                yield "\">
                    ";
                // line 342
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["footers"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["footer"]) {
                    // line 343
                    yield "                        <tr>
                            ";
                    // line 344
                    if ((($tmp = ($context["showmassiveactions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 345
                        yield "                                <td></td>
                            ";
                    }
                    // line 347
                    yield "                            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable($context["footer"]);
                    foreach ($context['_seq'] as $context["footer_col"] => $context["footerval"]) {
                        // line 348
                        yield "                                <td>";
                        yield Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["footerval"], "html", null, true));
                        yield "</td>
                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['footer_col'], $context['footerval'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 350
                    yield "                            ";
                    if ((($tmp =  !array_key_exists("nofilter", $context)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 351
                        yield "                                <td></td>
                            ";
                    }
                    // line 353
                    yield "                        </tr>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['footer'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 355
                yield "                </tfoot>
            ";
            }
            // line 357
            yield "        </table>
    </div>

    ";
            // line 360
            if ((($tmp = ($context["use_pager"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 361
                yield "        <div class=\"ms-auto d-inline-flex align-items-center d-none d-md-block my-2\">
            ";
                // line 362
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Entries to show:"), "html", null, true);
                yield "
            ";
                // line 363
                yield from $this->load("components/dropdown/limit.html.twig", 363)->unwrap()->yield($context);
                // line 364
                yield "        </div>
    ";
            }
            // line 366
            yield "
    <script type=\"text/javascript\">
    \$(function() {
        \$('.filter-select-multiple').select2();
    });
    </script>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "components/datatable.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  963 => 366,  959 => 364,  957 => 363,  953 => 362,  950 => 361,  948 => 360,  943 => 357,  939 => 355,  932 => 353,  928 => 351,  925 => 350,  916 => 348,  911 => 347,  907 => 345,  905 => 344,  902 => 343,  898 => 342,  893 => 341,  891 => 340,  888 => 339,  881 => 335,  877 => 334,  874 => 333,  871 => 332,  856 => 330,  852 => 328,  849 => 327,  843 => 326,  839 => 324,  833 => 322,  830 => 321,  824 => 319,  818 => 317,  815 => 316,  812 => 315,  806 => 312,  802 => 311,  797 => 310,  794 => 309,  791 => 308,  788 => 307,  785 => 306,  782 => 305,  779 => 304,  776 => 303,  774 => 302,  771 => 301,  765 => 299,  763 => 298,  753 => 297,  748 => 296,  745 => 295,  742 => 294,  739 => 293,  736 => 292,  733 => 291,  731 => 290,  729 => 289,  724 => 288,  722 => 287,  717 => 286,  715 => 285,  710 => 284,  708 => 283,  703 => 282,  701 => 281,  696 => 280,  694 => 279,  689 => 278,  687 => 277,  682 => 276,  680 => 275,  675 => 274,  673 => 273,  668 => 271,  662 => 268,  659 => 267,  657 => 266,  652 => 264,  646 => 261,  643 => 260,  641 => 259,  638 => 258,  636 => 257,  628 => 255,  625 => 254,  622 => 253,  619 => 252,  614 => 251,  610 => 249,  603 => 247,  599 => 246,  596 => 245,  594 => 244,  591 => 243,  589 => 242,  586 => 241,  580 => 239,  577 => 238,  571 => 236,  568 => 235,  562 => 233,  560 => 232,  552 => 231,  549 => 230,  546 => 229,  528 => 228,  526 => 227,  522 => 225,  518 => 223,  511 => 221,  508 => 220,  503 => 218,  499 => 217,  496 => 216,  489 => 212,  485 => 211,  480 => 209,  476 => 208,  472 => 207,  467 => 206,  464 => 205,  462 => 204,  460 => 203,  455 => 201,  451 => 200,  448 => 199,  446 => 198,  443 => 197,  441 => 194,  440 => 192,  438 => 191,  436 => 190,  433 => 189,  431 => 186,  430 => 184,  428 => 183,  426 => 182,  423 => 181,  414 => 178,  407 => 177,  403 => 176,  397 => 174,  394 => 173,  392 => 172,  389 => 171,  386 => 170,  382 => 169,  377 => 167,  373 => 165,  369 => 163,  367 => 162,  364 => 161,  361 => 160,  357 => 158,  352 => 155,  346 => 152,  340 => 150,  337 => 149,  331 => 146,  325 => 144,  323 => 143,  319 => 141,  317 => 140,  314 => 139,  307 => 137,  303 => 135,  301 => 134,  296 => 133,  291 => 131,  286 => 130,  284 => 129,  280 => 127,  278 => 126,  275 => 125,  272 => 124,  269 => 123,  266 => 122,  263 => 121,  260 => 120,  257 => 119,  254 => 118,  251 => 117,  246 => 116,  239 => 112,  235 => 111,  231 => 110,  227 => 108,  225 => 107,  222 => 106,  219 => 105,  215 => 103,  211 => 102,  206 => 101,  200 => 100,  197 => 99,  194 => 98,  191 => 97,  189 => 96,  179 => 94,  175 => 92,  173 => 91,  170 => 90,  168 => 89,  158 => 88,  155 => 87,  151 => 85,  149 => 84,  148 => 83,  146 => 82,  143 => 81,  140 => 80,  130 => 73,  123 => 68,  120 => 67,  113 => 63,  109 => 61,  106 => 60,  103 => 59,  100 => 58,  98 => 57,  92 => 55,  90 => 54,  87 => 53,  85 => 52,  82 => 50,  80 => 49,  77 => 48,  73 => 46,  71 => 45,  68 => 44,  66 => 43,  64 => 42,  62 => 41,  60 => 40,  58 => 39,  56 => 38,  54 => 37,  52 => 36,  50 => 35,  47 => 34,  45 => 33,  42 => 32,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "components/datatable.html.twig", "/var/www/glpi/templates/components/datatable.html.twig");
    }
}
