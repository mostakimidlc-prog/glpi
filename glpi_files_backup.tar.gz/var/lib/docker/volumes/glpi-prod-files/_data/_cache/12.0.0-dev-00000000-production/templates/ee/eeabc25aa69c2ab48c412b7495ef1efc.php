<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* install/agree_unstable.html.twig */
class __TwigTemplate_b3404de3faabe214d30eec04c1f57067 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 32
        yield "
";
        // line 33
        $macros["fields"] = $this->macros["fields"] = $this->load("components/form/fields_macros.html.twig", 33)->unwrap();
        // line 34
        yield "
<div class=\"alert alert-warning\">
   <strong>
      ";
        // line 37
        if ((($tmp = ($context["is_dev"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 38
            yield "         ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("You are using a development version, be careful!"), "html", null, true);
            yield "
      ";
        } else {
            // line 40
            yield "         ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("You are using a pre-release version, be careful!"), "html", null, true);
            yield "
      ";
        }
        // line 42
        yield "   </strong>
   <br>
   ";
        // line 44
        yield $macros["fields"]->getTemplateForMacro("macro_checkboxField", $context, 44, $this->getSourceContext())->macro_checkboxField(...["agree_unstable", 0, __("I know I am using a unstable version."), ["required" => true, "id" => "agree_unstable"]]);
        // line 47
        yield "
</div>
<script>
   \$(function() {
       \$('[name=\"continue\"]').on('click', function(event){
           if (!\$('#agree_unstable').is(':checked')) {
               event.preventDefault();
               alert('";
        // line 54
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Please check the unstable version checkbox."), "html", null, true);
        yield "');
           }
       });
   });
</script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "install/agree_unstable.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  81 => 54,  72 => 47,  70 => 44,  66 => 42,  60 => 40,  54 => 38,  52 => 37,  47 => 34,  45 => 33,  42 => 32,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "install/agree_unstable.html.twig", "/var/www/glpi/templates/install/agree_unstable.html.twig");
    }
}
